// change navbar styles on scroll

window.addEventListener('scroll', () => {
      document.querySelector('nav').classList.toggle 
      ('window-scroll', window.scrollY > 20)
})

// show/hide faq answer on click 

const faqs = document.querySelectorAll('.faq');

faqs.forEach(faq => {
    faq.addEventListener('click', () => {
        faq.classList.toggle('open');

          // change icon
    const icon = faq.querySelector('.faq__icon i');
    if (icon.className === 'fa-solid fa-plus') {
        icon.className = 'fa-solid fa-minus';
    } else {
        icon.className = 'fa-solid fa-plus' ;
    }
    })
  
})

// Testimonial swipper

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 30,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    // When window width is >= 600px 
     breakpoints: {
        600: {
            slidesPerView: 2
        }
     }
  });

// show/hide menu bar on click

const menu = document.querySelector('.nav__menu');
const menuBtn = document.querySelector('#open-menu-btn');
const closeBtn = document.querySelector('#close-menu-btn');
const headerImg = document.querySelector('.header__right')

// show menu button 
menuBtn.addEventListener('click', ()=> {
    menu.style.display = 'flex';
    headerImg.style.display = 'none';
    closeBtn.style.display = 'inline-block';
    menuBtn.style.display = 'none';
})

// close menu button
const closeNav = () => {
    menu.style.display = 'none';
    closeBtn.style.display = 'none';
    menuBtn.style.display = 'inline-block';
    headerImg.style.display = 'inline-block';
}
closeBtn.addEventListener('click', closeNav);

